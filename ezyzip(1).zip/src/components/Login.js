import React, { useState } from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import SignImg from './SignImg';
import MarkSheet from './MarkSheet';

const Login = () => {
    const[name,setName]=useState('');
    const[roll,setRoll]=useState('');
    const [showResult,setShowResult]=useState(false);

    const onchangename=(e)=>{
        setName(e.target.value);
    }

    const onchangeroll=(e)=>{
        setRoll(e.target.value);
    }

    const validSubmission=(e)=>{
        e.preventDefault();
        if(name && roll) setShowResult(true)
        else {
            setShowResult(false);
            alert('Please fill all the fields');
        }
    }

    return (
        showResult? <MarkSheet/> 
        :
        <>
            <div className="container mt-3" style={{padding:'20px 90px'}}>
                    <h2 className='text-center' style={{fontWeight:'bold'}}>Check your result</h2>
                <section className='d-flex justify-content-between'>
                    <div className="left_data p-3" style={{ paddingLeft:'100px',display:'flex', justifyContent:'center', alignItems:'center'}}>
                    <div style={{minWidth:'360px'}}>
                        <Form onSubmit={validSubmission}>

                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Name</Form.Label>
                                <Form.Control type="text" placeholder="Enter your name" value={name} onChange={onchangename} />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>University Roll No.</Form.Label>
                                <Form.Control type="number" min="1000" max="9999" value={roll} placeholder="Enter university roll" onChange={onchangeroll}/>
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Batch Year</Form.Label>
                                <Form.Select>
                                    <option>2019-2023</option>
                                    <option>2020-2024</option>
                                    <option>2021-2025</option>
                                    <option>2022-2026</option>
                                </Form.Select>
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Branch</Form.Label>
                                <Form.Select>
                                    <option>CSE</option>
                                    <option>MCA</option>
                                    <option>ECE</option>
                                </Form.Select>
                            </Form.Group>
                            <div style={{display:'flex', justifyContent:'center', alignItems:'center'}}>
                            <Button className='mt-3' variant="success" type="submit" style={{textAlign:'center', width:'100%'}}>
                                Submit
                            </Button>
                            </div>
                        </Form>
                    </div>
                    </div>
                    <div className='p-3' style={{display:'flex', justifyContent:'center', alignItems:'center'}}><SignImg /></div>
                </section>
            </div>
        </>
    )
}

export default Login
